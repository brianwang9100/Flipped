FLIPPED
=======

CS2100 GBA GAME
MODE4
BRIAN WANG

CONTROLS
========
Press A to reverse the direction of the mainCharacter.
Press B to use a "split" and reverse the direction of the obstacles.

GAMEPLAY
========
You start off with one "split" which can be depleted in order to reverse the direction of the obstacles.
You win by collecting the 10 animated orbs. Every two collected orbs generates a split, which you can press b to reverse the velocities of the obstacles.
You lose by getting hit by an obstacle.
